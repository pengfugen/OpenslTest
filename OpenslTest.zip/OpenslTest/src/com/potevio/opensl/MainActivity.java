package com.potevio.opensl;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener{
	private static final String THIS_FILE = "MainActivity";
    private static final int REQUEST_PERMISSION = 0x1000;
    private static final int REQUEST_OVERLAY_PERMISSION_CODE = 0x1001;
    
    private Spinner channelSelect;
    private Spinner sampleRateSelect;
    private Spinner bitsSelect;
    private Button btnRecord;
    private Button btnPlay;
    private ScheduledExecutorService timerService;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            checkPermission(this);
        }
		
		this.channelSelect = findViewById(R.id.channel_select);
		this.sampleRateSelect = findViewById(R.id.sample_rate_select);
		this.bitsSelect = findViewById(R.id.bits_select);
		this.btnRecord = findViewById(R.id.record);
		this.btnPlay = findViewById(R.id.play);
		
		this.btnRecord.setOnClickListener(this);
		this.btnPlay.setOnClickListener(this);
		
		Opensl.init();
	}

	private void checkPermission(Context context) {
        PackageManager pm = context.getPackageManager();
        String pkgName = context.getPackageName();
        boolean permission = (PackageManager.PERMISSION_GRANTED == pm.checkPermission(android.Manifest.permission.CAMERA, pkgName)
                && PackageManager.PERMISSION_GRANTED == pm.checkPermission(android.Manifest.permission.RECORD_AUDIO, pkgName)
                && PackageManager.PERMISSION_GRANTED == pm.checkPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE, pkgName)
                && PackageManager.PERMISSION_GRANTED == pm.checkPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE, pkgName)
                && PackageManager.PERMISSION_GRANTED == pm.checkPermission(android.Manifest.permission.READ_PHONE_STATE, pkgName));
        if (!permission) {
            this.requestPermissions(new String[]{
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.RECORD_AUDIO,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    android.Manifest.permission.READ_PHONE_STATE},REQUEST_PERMISSION);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(context)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + pkgName));
                startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION_CODE);
            }
        }
    }
	
	@Override
	public void onRequestPermissionsResult(int requestCode,
			String[] permissions,
			int[] grantResults) {
		// TODO Auto-generated method stub
		if (requestCode == REQUEST_PERMISSION){
            for (int grantResult: grantResults){
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, getResources().getString(R.string.has_no_camera_permission), Toast.LENGTH_SHORT).show();
                }
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, getResources().getString(R.string.has_no_record_permission), Toast.LENGTH_SHORT).show();
                }
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, getResources().getString(R.string.has_no_wr_sdcard_permission), Toast.LENGTH_SHORT).show();
                }
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this,  getResources().getString(R.string.has_no_read_phone_state_permission), Toast.LENGTH_SHORT).show();
                }
            }
        } else if (requestCode == REQUEST_OVERLAY_PERMISSION_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(this)) {
                    // SYSTEM_ALERT_WINDOW permission not granted...
                    Toast.makeText(this,  getResources().getString(R.string.has_no_system_dialog_permission), Toast.LENGTH_SHORT).show();
                }
            }
        }
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		this.finish();
		super.onBackPressed();
	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		Opensl.stopPlay();
		Opensl.stopRecord();
		Opensl.release();
		super.onDestroy();
	}

	@Override
	public void onPointerCaptureChanged(boolean hasCapture) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int channel = Integer.valueOf(this.channelSelect.getSelectedItem().toString());
		int sampleRate = Integer.valueOf(this.sampleRateSelect.getSelectedItem().toString());
		int bits = Integer.valueOf(this.bitsSelect.getSelectedItem().toString());
		switch (v.getId()) {
		case R.id.record:
			this.recordClick(channel, sampleRate, bits);
			break;
		case R.id.play:
			this.playClick(channel, sampleRate, bits);
			break;

		default:
			break;
		}
	}
	
	private void recordClick(int channel,int sampleRate,int bits){
		if(this.btnRecord.getText().equals(getResources().getString(R.string.record))){
			Opensl.stopPlay();
			this.btnPlay.setText(getResources().getString(R.string.play));
			if(Opensl.startRecord(channel,sampleRate,bits) == 0){
				startRecordTimer();
				this.btnRecord.setText(getResources().getString(R.string.stop));
			} else {
				Toast.makeText(this, getResources().getString(R.string.error_not_support_params), Toast.LENGTH_SHORT).show();
			}
		}else if(this.btnRecord.getText().equals(getResources().getString(R.string.stop))){
			Opensl.stopRecord();
			this.btnRecord.setText(getResources().getString(R.string.record));
			if(timerService != null){
				timerService.shutdownNow();
				timerService = null;
			}
		}
	}
	private void playClick(int channel,int sampleRate,int bits){
		if(this.btnPlay.getText().equals(getResources().getString(R.string.play))){
			Opensl.stopRecord();
			this.btnRecord.setText(getResources().getString(R.string.record));
			if(timerService != null){
				timerService.shutdownNow();
				timerService = null;
			}
			if(Opensl.startPlay(1,sampleRate,bits) == 0){
				this.btnPlay.setText(getResources().getString(R.string.stop));
			} else {
				Toast.makeText(this, getResources().getString(R.string.error_not_support_params), Toast.LENGTH_SHORT).show();
			}
		}else if(this.btnPlay.getText().equals(getResources().getString(R.string.stop))){
			Opensl.stopPlay();
			this.btnPlay.setText(getResources().getString(R.string.play));
		}
	}
	
	private void startRecordTimer(){
		if(this.timerService == null){
			this.timerService = new ScheduledThreadPoolExecutor(1);
		}
		this.timerService.scheduleAtFixedRate(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Opensl.stopRecord();
				btnRecord.setText(getResources().getString(R.string.record));
				if(timerService != null){
					timerService.shutdownNow();
					timerService = null;
				}
			}
		}, 60, 60, TimeUnit.SECONDS);
	}
}
