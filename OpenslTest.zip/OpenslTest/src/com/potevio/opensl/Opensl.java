package com.potevio.opensl;

public class Opensl {
	static{
		System.loadLibrary("opensl_android");
		}
	public final static native int init();
	public final static native int startPlay(int channel,int sample_rate,int bits);
	public final static native int stopPlay();
	public final static native int startRecord(int channel,int sample_rate,int bits);
	public final static native int stopRecord();
	public final static native int release();
}
