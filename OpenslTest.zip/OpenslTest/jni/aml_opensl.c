#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jni.h>
#include <android/log.h>

#include <SLES/OpenSLES.h>
#include <system/audio-base.h>

#ifdef __ANDROID__
    #include <SLES/OpenSLES_Android.h>
    #include <SLES/OpenSLES_AndroidConfiguration.h>
    #include <sys/system_properties.h>
    #include <android/api-level.h>

    #define W_SLBufferQueueItf SLAndroidSimpleBufferQueueItf
    #define W_SLBufferQueueState SLAndroidSimpleBufferQueueState
    #define W_SL_IID_BUFFERQUEUE SL_IID_ANDROIDSIMPLEBUFFERQUEUE
#else
    #define W_SLBufferQueueItf SLBufferQueueItf
    #define W_SLBufferQueueState SLBufferQueueState
    #define W_SL_IID_BUFFERQUEUE SL_IID_BUFFERQUEUE
#endif

#define THIS_FILE	"nst_opensl.c"
#define DRIVER_NAME	"OpenSL"

#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,THIS_FILE,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,THIS_FILE,__VA_ARGS__)


#define NUM_BUFFERS 2

/* add by lindroid 20170323 */
#define FILE_DEBUG

#ifdef FILE_DEBUG
#include<stdio.h>
FILE* recordFile = NULL;
FILE* playFile = NULL;
#endif

typedef struct opensl_aud_factory
{    
    SLObjectItf              engineObject;
    SLEngineItf              engineEngine;
    SLObjectItf              outputMixObject;
}opensl_aud_factory;

/*
 * Sound stream descriptor.
 * This struct may be used for both unidirectional or bidirectional sound
 * streams.
 */
typedef struct opensl_aud_stream
{   
	char            	name[48];
	int           		quit_play_flag;
	int           		quit_record_flag;
	
    /* Player */
    SLObjectItf         playerObj;
    SLPlayItf           playerPlay;
    SLVolumeItf         playerVol;
	SLEffectSendItf 	PlayerEff;
    unsigned            playerBufferSize;
    char               *playerBuffer[NUM_BUFFERS];
    int                 playerBufIdx;
    
    /* Recorder */
    SLObjectItf         recordObj;
    SLRecordItf         recordRecord;
    unsigned            recordBufferSize;
    char               *recordBuffer[NUM_BUFFERS];
    int                 recordBufIdx;

    W_SLBufferQueueItf  playerBufQ;
    W_SLBufferQueueItf  recordBufQ;
}opensl_aud_stream;

static opensl_aud_factory oa_factory;
static opensl_aud_stream oa_stream;

/* Factory prototypes */
static int opensl_init(opensl_aud_factory *factory);
static int opensl_destroy(opensl_aud_factory *factory);
static int opensl_create_play_stream(opensl_aud_factory *factory,
										opensl_aud_stream *stream,int channel,
										int sample_rate,int bits);
static int opensl_create_record_stream(opensl_aud_factory *factory,
										opensl_aud_stream *stream,int channel,
										int sample_rate,int bits);

/* Stream prototypes */
//static int strm_get_param(opensl_aud_stream *strm);
//static int strm_get_cap(opensl_aud_stream *strm,
//                                void *value);
//static int strm_set_cap(opensl_aud_stream *strm,
//                                const void *value);
static int strm_start_play(opensl_aud_stream *strm);
static int strm_stop_play(opensl_aud_stream *strm);
static int strm_destroy_play(opensl_aud_stream *strm);
static int strm_start_record(opensl_aud_stream *strm);
static int strm_stop_record(opensl_aud_stream *strm);
static int strm_destroy_record(opensl_aud_stream *strm);

/* This callback is called every time a buffer finishes playing. */
void bqPlayerCallback(W_SLBufferQueueItf bq, void *context)
{
    struct opensl_aud_stream *stream = (struct opensl_aud_stream*) context;
    SLresult result;
    //int status;
    
    if (!stream->quit_play_flag) {
        char * buf;
        
        buf = stream->playerBuffer[stream->playerBufIdx++];
		
#ifdef FILE_DEBUG
		if (playFile != NULL){
			if(feof(playFile) == 0){
				fread(buf,1,stream->playerBufferSize,playFile);
			} else {
				strm_stop_play(stream);
			}
		}
#endif
        result = (*bq)->Enqueue(bq, buf, stream->playerBufferSize);
        if (result != SL_RESULT_SUCCESS) {
            LOGE("Unable to enqueue next player buffer !!! %d",result);
        }
        
        stream->playerBufIdx %= NUM_BUFFERS;
    }
}

/* This callback handler is called every time a buffer finishes recording */
void bqRecorderCallback(W_SLBufferQueueItf bq, void *context)
{
    struct opensl_aud_stream *stream = (struct opensl_aud_stream*) context;
    SLresult result;
    //int status;
    
    if (!stream->quit_record_flag) {
        char *buf;
        
        buf = stream->recordBuffer[stream->recordBufIdx++];
#ifdef FILE_DEBUG
		if (recordFile != NULL){
			fwrite(buf,1,stream->recordBufferSize,recordFile);
		}
#endif
        /* And now enqueue next buffer */
        result = (*bq)->Enqueue(bq, buf, stream->recordBufferSize);
        if (result != SL_RESULT_SUCCESS) {
            LOGE("Unable to enqueue next record buffer !!! %d",result);
        }
        
        stream->recordBufIdx %= NUM_BUFFERS;
    }
}

int opensl_to_error(SLresult code)
{
    switch(code) {
	case SL_RESULT_SUCCESS:
            return 0;
	case SL_RESULT_PRECONDITIONS_VIOLATED:
	case SL_RESULT_PARAMETER_INVALID:
	case SL_RESULT_CONTENT_CORRUPTED:
	case SL_RESULT_FEATURE_UNSUPPORTED:
            return 420009;
	case SL_RESULT_MEMORY_FAILURE:
	case SL_RESULT_BUFFER_INSUFFICIENT:
            return 70007;
	case SL_RESULT_RESOURCE_ERROR:
	case SL_RESULT_RESOURCE_LOST:
	case SL_RESULT_CONTROL_LOST:
            return 420007;
	case SL_RESULT_CONTENT_UNSUPPORTED:
            return 70012;
	default:
            return 420001;
    }
}

static int opensl_init(opensl_aud_factory *factory)
{
	SLresult result;
	
    /* Create engine */
    result = slCreateEngine(&factory->engineObject, 0, NULL, 0, NULL, NULL);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Cannot create engine %d ", result);
        return opensl_to_error(result);
    }
    
    /* Realize the engine */
    result = (*factory->engineObject)->Realize(factory->engineObject, SL_BOOLEAN_FALSE);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Cannot realize engine");
		opensl_destroy(factory);
        return opensl_to_error(result);
    }
    
    /* Get the engine interface, which is needed in order to create
     * other objects.
     */
    result = (*factory->engineObject)->GetInterface(factory->engineObject,
                                               SL_IID_ENGINE,
                                               &factory->engineEngine);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Cannot get engine interface");
		opensl_destroy(factory);
        return opensl_to_error(result);
    }
    
    /* Create output mix */
    result = (*factory->engineEngine)->CreateOutputMix(factory->engineEngine,
                                                  &factory->outputMixObject,
                                                  0, NULL, NULL);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Cannot create output mix");
		opensl_destroy(factory);
        return opensl_to_error(result);
    }
    
    /* Realize the output mix */
    result = (*factory->outputMixObject)->Realize(factory->outputMixObject,
                                             SL_BOOLEAN_FALSE);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Cannot realize output mix");
		opensl_destroy(factory);
        return opensl_to_error(result);
    }
	
    LOGI("OpenSL sound library initialized");
	
    return 0;
}

/* API: Destroy factory */
static int opensl_destroy(opensl_aud_factory *factory)
{
    /* Destroy Output Mix object */
    if (factory->outputMixObject) {
        (*factory->outputMixObject)->Destroy(factory->outputMixObject);
        factory->outputMixObject = NULL;
    }
    
    /* Destroy engine object, and invalidate all associated interfaces */
    if (factory->engineObject) {
        (*factory->engineObject)->Destroy(factory->engineObject);
        factory->engineObject = NULL;
        factory->engineEngine = NULL;
    }
	LOGI("OpenSL sound library shutting down..");
	
    return 0;
}

/* API: create stream */
static int opensl_create_play_stream(opensl_aud_factory *factory,opensl_aud_stream *stream,int channel,int sample_rate,int bits)
{
    /* Audio sink for recorder and audio source for player */
#ifdef __ANDROID__
    SLDataLocator_AndroidSimpleBufferQueue loc_bq =
        { SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, NUM_BUFFERS };
#else
    SLDataLocator_BufferQueue loc_bq =
        { SL_DATALOCATOR_BUFFERQUEUE, NUM_BUFFERS };
#endif
    int status = 0;
    int i, bufferSize;
    SLresult result;
    SLDataFormat_PCM format_pcm;

    LOGI("Creating OpenSL play stream");
	LOGI("Creating OpenSL play stream channel = %d",channel);
	
	int samples_per_frame = sample_rate * 20 / 1000;
	int bits_per_sample = bits;
    bufferSize = samples_per_frame * bits_per_sample / 8;

    /* Configure audio PCM format */
    format_pcm.formatType = SL_DATAFORMAT_PCM;
    format_pcm.numChannels = channel;
    /* Here samples per sec should be supported else we will get an error */
    format_pcm.samplesPerSec  = (SLuint32) sample_rate * 1000;
    format_pcm.bitsPerSample = (SLuint16) bits_per_sample;
    format_pcm.containerSize = (SLuint16) bits_per_sample;
    format_pcm.channelMask = SL_SPEAKER_FRONT_CENTER;
    format_pcm.endianness = SL_BYTEORDER_LITTLEENDIAN;

    /* create play stream */
	/* Audio source */
	SLDataSource audioSrc = {&loc_bq, &format_pcm};
	/* Audio sink */
	SLDataLocator_OutputMix loc_outmix = {SL_DATALOCATOR_OUTPUTMIX,
										  factory->outputMixObject};
	SLDataSink audioSnk = {&loc_outmix, NULL};
	/* Audio interface */
#ifdef __ANDROID__
	int numIface = 3;
	const SLInterfaceID ids[3] = {SL_IID_BUFFERQUEUE,
								  SL_IID_VOLUME,
								  SL_IID_ANDROIDCONFIGURATION};
	const SLboolean req[3] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE,
							  SL_BOOLEAN_TRUE};
	SLAndroidConfigurationItf playerConfig;
	SLint32 streamType = SL_ANDROID_STREAM_VOICE;
#else
	int numIface = 2;
	const SLInterfaceID ids[2] = {SL_IID_BUFFERQUEUE,
								  SL_IID_VOLUME};
	const SLboolean req[2] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};
#endif
	
	/* Create audio player */
	result = (*factory->engineEngine)->CreateAudioPlayer(factory->engineEngine,
													&stream->playerObj,
													&audioSrc, &audioSnk,
													numIface, ids, req);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot create audio player: %d", result);
		goto on_error;
	}

#ifdef __ANDROID__
	/* Set Android configuration */
	result = (*stream->playerObj)->GetInterface(stream->playerObj,
												SL_IID_ANDROIDCONFIGURATION,
												&playerConfig);
	if (result == SL_RESULT_SUCCESS && playerConfig) {
		result = (*playerConfig)->SetConfiguration(
					 playerConfig, SL_ANDROID_KEY_STREAM_TYPE,
					 &streamType, sizeof(SLint32));
	}
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Warning: Unable to set android layer configuration");
	}
#endif

	/* Realize the player */
	result = (*stream->playerObj)->Realize(stream->playerObj,
										   SL_BOOLEAN_FALSE);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot realize player : %d", result);
		goto on_error;
	}
	
	/* Get the play interface */
	result = (*stream->playerObj)->GetInterface(stream->playerObj,
												SL_IID_PLAY,
												&stream->playerPlay);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot get play interface");
		goto on_error;
	}
	
	/* Get the buffer queue interface */
	result = (*stream->playerObj)->GetInterface(stream->playerObj,
												SL_IID_BUFFERQUEUE,
												&stream->playerBufQ);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot get buffer queue interface");
		goto on_error;
	}
	
	/* Get the volume interface */
	result = (*stream->playerObj)->GetInterface(stream->playerObj,
												SL_IID_VOLUME,
												&stream->playerVol);
	
	/* Register callback on the buffer queue */
	result = (*stream->playerBufQ)->RegisterCallback(stream->playerBufQ,
													 bqPlayerCallback,
													 (void *)stream);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot register player callback");
		goto on_error;
	}
	
	stream->playerBufferSize = bufferSize;
	for (i = 0; i < NUM_BUFFERS; i++) {
		stream->playerBuffer[i] = (char *)malloc(stream->playerBufferSize);
	}
	
	LOGI("Create OpenSL play stream success");
    return status;
    
on_error:
    strm_destroy_play(stream);
    return 420009;
}

/* API: create stream */
static int opensl_create_record_stream(opensl_aud_factory *factory,opensl_aud_stream *stream,int channel,int sample_rate,int bits)
{
    /* Audio sink for recorder and audio source for player */
#ifdef __ANDROID__
    SLDataLocator_AndroidSimpleBufferQueue loc_bq =
        { SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, NUM_BUFFERS };
#else
    SLDataLocator_BufferQueue loc_bq =
        { SL_DATALOCATOR_BUFFERQUEUE, NUM_BUFFERS };
#endif
    int status = 0;
    int i, bufferSize;
    SLresult result;
    SLDataFormat_PCM format_pcm;

    LOGI("Creating OpenSL record stream===1");
	LOGI("Creating OpenSL record stream channel = %d",channel);
	
	int samples_per_frame = sample_rate * 20 / 1000;
	int bits_per_sample = bits;
    bufferSize = samples_per_frame * bits_per_sample / 8;

    /* Configure audio PCM format */
    format_pcm.formatType = SL_DATAFORMAT_PCM;
    format_pcm.numChannels = channel;
    /* Here samples per sec should be supported else we will get an error */
    format_pcm.samplesPerSec  = (SLuint32) sample_rate * 1000;
    format_pcm.bitsPerSample = (SLuint16) bits_per_sample;
    format_pcm.containerSize = (SLuint16) bits_per_sample;
	switch(channel) {
		case 1:
		    format_pcm.channelMask = AUDIO_CHANNEL_IN_MONO;
		    break;
		case 2:
		    format_pcm.channelMask = AUDIO_CHANNEL_IN_STEREO;
		    break;
		case 4:
		    format_pcm.channelMask = AUDIO_CHANNEL_IN_STEREO | AUDIO_CHANNEL_IN_FRONT_BACK;
		    break;
		default:
		    format_pcm.channelMask = AUDIO_CHANNEL_IN_MONO;
		    break;
	}
    format_pcm.endianness = SL_BYTEORDER_LITTLEENDIAN;

	/* create record stream */
	/* Audio source */
	SLDataLocator_IODevice loc_dev = {SL_DATALOCATOR_IODEVICE,
									  SL_IODEVICE_AUDIOINPUT,
									  SL_DEFAULTDEVICEID_AUDIOINPUT,
									  NULL};
	SLDataSource audioSrc = {&loc_dev, NULL};
	/* Audio sink */
	SLDataSink audioSnk = {&loc_bq, &format_pcm};
	/* Audio interface */
#ifdef __ANDROID__
	int numIface = 2;
	const SLInterfaceID ids[2] = {W_SL_IID_BUFFERQUEUE,
								  SL_IID_ANDROIDCONFIGURATION};
	const SLboolean req[2] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};
	SLAndroidConfigurationItf recorderConfig;
#else
	int numIface = 1;
	const SLInterfaceID ids[1] = {W_SL_IID_BUFFERQUEUE};
	const SLboolean req[1] = {SL_BOOLEAN_TRUE};
#endif
	
	/* Create audio recorder
	 * (requires the RECORD_AUDIO permission)
	 */
	result = (*factory->engineEngine)->CreateAudioRecorder(factory->engineEngine,
													  &stream->recordObj,
													  &audioSrc, &audioSnk,
													  numIface, ids, req);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot create recorder: %d", result);
		goto on_error;
	}

#ifdef __ANDROID__
	/* Set Android configuration */
	result = (*stream->recordObj)->GetInterface(stream->recordObj,
												SL_IID_ANDROIDCONFIGURATION,
												&recorderConfig);
	if (result == SL_RESULT_SUCCESS) {
		SLint32 streamType = SL_ANDROID_RECORDING_PRESET_GENERIC;
#if __ANDROID_API__ >= 14
	streamType = SL_ANDROID_RECORDING_PRESET_VOICE_COMMUNICATION;
#endif
#if 0
		/* Android-L (android-21) removes __system_property_get
		 * from the NDK.
	 */
		char sdk_version[PROP_VALUE_MAX];
		pj_str_t pj_sdk_version;
		int sdk_v;

		__system_property_get("ro.build.version.sdk", sdk_version);
		pj_sdk_version = pj_str(sdk_version);
		sdk_v = pj_strtoul(&pj_sdk_version);
		if (sdk_v >= 14)
			streamType = SL_ANDROID_RECORDING_PRESET_VOICE_COMMUNICATION;
		LOGI("Recording stream type %d, SDK : %d",
							  streamType, sdk_v);
#endif
		result = (*recorderConfig)->SetConfiguration(
					 recorderConfig, SL_ANDROID_KEY_RECORDING_PRESET,
					 &streamType, sizeof(SLint32));
	}
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Warning: Unable to set android recorder configuration");
	}
#endif
	
	/* Realize the recorder */
	result = (*stream->recordObj)->Realize(stream->recordObj,
										   SL_BOOLEAN_FALSE);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot realize recorder : %d", result);
		goto on_error;
	}
	
	/* Get the record interface */
	result = (*stream->recordObj)->GetInterface(stream->recordObj,
												SL_IID_RECORD,
												&stream->recordRecord);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot get record interface");
		goto on_error;
	}
	
	/* Get the buffer queue interface */
	result = (*stream->recordObj)->GetInterface(
				 stream->recordObj, W_SL_IID_BUFFERQUEUE,
				 &stream->recordBufQ);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot get recorder buffer queue iface");
		goto on_error;
	}
	
	/* Register callback on the buffer queue */
	result = (*stream->recordBufQ)->RegisterCallback(stream->recordBufQ,
													 bqRecorderCallback, 
													 (void *)stream);
	if (result != SL_RESULT_SUCCESS) {
		LOGE("Cannot register recorder callback");
		goto on_error;
	}
	
	stream->recordBufferSize = bufferSize;
	for (i = 0; i < NUM_BUFFERS; i++) {
		stream->recordBuffer[i] = (char *)malloc(stream->recordBufferSize);
	}
	
	LOGI("Create OpenSL record stream success");
    return status;
    
on_error:
    strm_destroy_record(stream);
    return 420009;
}

/* API: get capability */
/*static int strm_get_cap(opensl_aud_stream *stream,
                                void *pval)
{    
    int status = 420008;
    
	if (stream->playerVol) {
		SLresult res;
		SLmillibel vol, mvol;
		
		res = (*stream->playerVol)->GetMaxVolumeLevel(stream->playerVol,
													&mvol);
		if (res == SL_RESULT_SUCCESS) {
			res = (*stream->playerVol)->GetVolumeLevel(stream->playerVol,
													 &vol);
			if (res == SL_RESULT_SUCCESS) {
				*(int *)pval = ((int)vol - SL_MILLIBEL_MIN) * 100 /
							   ((int)mvol - SL_MILLIBEL_MIN);
				return 0;
			}
		}
	}
    
    return status;
}*/

/* API: set capability */
/*static int strm_set_cap(opensl_aud_stream *stream,
                                const void *value)
{
	if (stream->playerVol) {
		SLresult res;
		SLmillibel vol, mvol;
		
		res = (*stream->playerVol)->GetMaxVolumeLevel(stream->playerVol,
													&mvol);
		if (res == SL_RESULT_SUCCESS) {
			vol = (SLmillibel)(*(int *)value *
				  ((int)mvol - SL_MILLIBEL_MIN) / 100 + SL_MILLIBEL_MIN);
			res = (*stream->playerVol)->SetVolumeLevel(stream->playerVol,
													 vol);
			if (res == SL_RESULT_SUCCESS)
				return 0;
		}
	}

    return 420008;
}*/

/* API: start play stream. */
static int strm_start_play(opensl_aud_stream *stream)
{
    int i;
    SLresult result = SL_RESULT_SUCCESS;
#ifdef FILE_DEBUG
	playFile = fopen("/mnt/vendor/tmp/opensl.pcm","rb");
#endif

    LOGI("Starting %s stream..", stream->name);
    stream->quit_play_flag = 0;

    if (stream->playerPlay && stream->playerBufQ) {
        /* Set the player's state to playing */
        result = (*stream->playerPlay)->SetPlayState(stream->playerPlay,
                                                     SL_PLAYSTATE_PLAYING);
        if (result != SL_RESULT_SUCCESS) {
            LOGE("Cannot start player");
            goto on_error;
        }
        
        for (i = 0; i < NUM_BUFFERS; i++) {
            memset(stream->playerBuffer[i],0, stream->playerBufferSize/100);
            result = (*stream->playerBufQ)->Enqueue(stream->playerBufQ,
                                                stream->playerBuffer[i],
                                                stream->playerBufferSize/100);
        }
    }
    
    LOGI("%s stream started", stream->name);
    return 0;
    
on_error:
    if (result != SL_RESULT_SUCCESS)
        strm_stop_play(stream);
    return opensl_to_error(result);
}

/* API: start record stream. */
static int strm_start_record(opensl_aud_stream *stream)
{
    int i;
    SLresult result = SL_RESULT_SUCCESS;
	
#ifdef FILE_DEBUG
	recordFile = fopen("/mnt/vendor/tmp/opensl.pcm","wb");
#endif
 
    LOGI("Starting %s stream..", stream->name);
    stream->quit_record_flag = 0;

    if (stream->recordBufQ && stream->recordRecord) {
        /* Enqueue an empty buffer to be filled by the recorder
         * (for streaming recording, we need to enqueue at least 2 empty
         * buffers to start things off)
         */
        for (i = 0; i < NUM_BUFFERS; i++) {
            result = (*stream->recordBufQ)->Enqueue(stream->recordBufQ,
                                                stream->recordBuffer[i],
                                                stream->recordBufferSize);
        }
        
        result = (*stream->recordRecord)->SetRecordState(
                     stream->recordRecord, SL_RECORDSTATE_RECORDING);
        if (result != SL_RESULT_SUCCESS) {
            LOGE("Cannot start recorder");
            goto on_error;
        }
    }
    
    if (stream->playerPlay && stream->playerBufQ) {
        /* Set the player's state to playing */
        result = (*stream->playerPlay)->SetPlayState(stream->playerPlay,
                                                     SL_PLAYSTATE_PLAYING);
        if (result != SL_RESULT_SUCCESS) {
            LOGE("Cannot start player");
            goto on_error;
        }
        
        for (i = 0; i < NUM_BUFFERS; i++) {
            memset(stream->playerBuffer[i],0, stream->playerBufferSize/100);
            result = (*stream->playerBufQ)->Enqueue(stream->playerBufQ,
                                                stream->playerBuffer[i],
                                                stream->playerBufferSize/100);
        }
    }
    
    LOGI("%s stream started", stream->name);
    return 0;
    
on_error:
    if (result != SL_RESULT_SUCCESS)
        strm_stop_record(stream);
    return opensl_to_error(result);
}

/* API: stop play stream. */
static int strm_stop_play(opensl_aud_stream *stream)
{
    if (stream->quit_play_flag)
        return 0;
    
    LOGI("Stopping play stream");
    
    stream->quit_play_flag = 1;    

    if (stream->playerBufQ && stream->playerPlay) {
        /* Wait until the PCM data is done playing, the buffer queue callback
         * will continue to queue buffers until the entire PCM data has been
         * played. This is indicated by waiting for the count member of the
         * SLBufferQueueState to go to zero.
         */
/*      
        SLresult result;
        W_SLBufferQueueState state;

        result = (*stream->playerBufQ)->GetState(stream->playerBufQ, &state);
        while (state.count) {
            (*stream->playerBufQ)->GetState(stream->playerBufQ, &state);
        } */
        /* Stop player */
        (*stream->playerPlay)->SetPlayState(stream->playerPlay,
                                            SL_PLAYSTATE_STOPPED);
    }
#ifdef FILE_DEBUG
	if (playFile != NULL){
		fclose(playFile);
	}
#endif
    LOGI("OpenSL play stream stopped");
    
    return 0;
    
}

/* API: stop record stream. */
static int strm_stop_record(opensl_aud_stream *stream)
{
    if (stream->quit_record_flag)
        return 0;
    
    LOGI("Stopping record stream");
    
    stream->quit_record_flag = 1;    
    
    if (stream->recordBufQ && stream->recordRecord) {
        /* Stop recording and clear buffer queue */
        (*stream->recordRecord)->SetRecordState(stream->recordRecord,
                                                  SL_RECORDSTATE_STOPPED);
        (*stream->recordBufQ)->Clear(stream->recordBufQ);
    }
#ifdef FILE_DEBUG
	if (recordFile != NULL){
		fclose(recordFile);
	}
#endif
    LOGI("OpenSL record stream stopped");
    
    return 0;
    
}

/* API: destroy play stream. */
static int strm_destroy_play(opensl_aud_stream *stream)
{    
    /* Stop the stream */
    strm_stop_play(stream);
    
    if (stream->playerObj) {
        /* Destroy the player */
        (*stream->playerObj)->Destroy(stream->playerObj);
        /* Invalidate all associated interfaces */
        stream->playerObj = NULL;
        stream->playerPlay = NULL;
        stream->playerBufQ = NULL;
        stream->playerVol = NULL;
    }
	
    LOGI("OpenSL play stream destroyed");
    
    return 0;
}

/* API: destroy record stream. */
static int strm_destroy_record(opensl_aud_stream *stream)
{    
    /* Stop the stream */
	strm_stop_record(stream);
    
    if (stream->recordObj) {
        /* Destroy the recorder */
        (*stream->recordObj)->Destroy(stream->recordObj);
        /* Invalidate all associated interfaces */
        stream->recordObj = NULL;
        stream->recordRecord = NULL;
        stream->recordBufQ = NULL;
    }
	
    LOGI("OpenSL record stream destroyed");
    
    return 0;
}
/* 
  * Java:固定的头
  * com_potevio_audio:上层调用此函数包名称 
  * Opensl:上层调用此函数的类名
  * init:上层调用的函数名
   * 这几个命名一定要对应，否则上层调用会出现错误:"java.lang.UnsatisfieldLinkError:Native method not found" 
   */
JNIEXPORT jint JNICALL Java_com_potevio_opensl_Opensl_init(JNIEnv * env, jclass obj)
{
	LOGI("Opensl_init %d %d",(env == NULL), (obj == NULL));
	
	opensl_init(&oa_factory);
    return 0;
}
/* 
  * Java:固定的头
  * com_potevio_audio:上层调用此函数包名称 
  * Opensl:上层调用此函数的类名
  * startPlay:上层调用的函数名
   * 这几个命名一定要对应，否则上层调用会出现错误:"java.lang.UnsatisfieldLinkError:Native method not found" 
   */
JNIEXPORT jint JNICALL Java_com_potevio_opensl_Opensl_startPlay(JNIEnv * env, jclass obj,jint channel,jint sample_rate,jint bits)
{
	LOGI("Opensl_startPlay %d, %d", (env == NULL), (obj == NULL));
	jint status = 0;
	status = opensl_create_play_stream(&oa_factory,&oa_stream,channel,sample_rate,bits);
		
	if(status == 0){
		strm_start_play(&oa_stream);
	}
	return status;
}
/* 
  * Java:固定的头
  * com_potevio_audio:上层调用此函数包名称 
  * Opensl:上层调用此函数的类名
  * stopPlay:上层调用的函数名
   * 这几个命名一定要对应，否则上层调用会出现错误:"java.lang.UnsatisfieldLinkError:Native method not found" 
   */
JNIEXPORT jint JNICALL Java_com_potevio_opensl_Opensl_stopPlay(JNIEnv * env, jclass obj)
{
	LOGI("Opensl_stopPlay %d, %d", (env == NULL), (obj == NULL));
	return strm_destroy_play(&oa_stream);
}
/* 
  * Java:固定的头
  * com_potevio_audio:上层调用此函数包名称 
  * Opensl:上层调用此函数的类名
  * startRecord:上层调用的函数名
   * 这几个命名一定要对应，否则上层调用会出现错误:"java.lang.UnsatisfieldLinkError:Native method not found" 
   */
JNIEXPORT jint JNICALL Java_com_potevio_opensl_Opensl_startRecord(JNIEnv * env, jclass obj,jint channel,jint sample_rate,jint bits)
{
	LOGI("Opensl_startRecord %d, %d", (env == NULL), (obj == NULL));
	jint status = 0;
	status = opensl_create_record_stream(&oa_factory,&oa_stream,channel,sample_rate,bits);
	if(status == 0){
		strm_start_record(&oa_stream);
	}
	return status;
}
/* 
  * Java:固定的头
  * com_potevio_audio:上层调用此函数包名称 
  * Opensl:上层调用此函数的类名
  * stopRecord:上层调用的函数名
   * 这几个命名一定要对应，否则上层调用会出现错误:"java.lang.UnsatisfieldLinkError:Native method not found" 
   */
JNIEXPORT jint JNICALL Java_com_potevio_opensl_Opensl_stopRecord(JNIEnv * env, jclass obj)
{
	LOGI("Opensl_stopRecord %d, %d", (env == NULL), (obj == NULL));
	return strm_destroy_record(&oa_stream);
}
/* 
  * Java:固定的头
  * com_potevio_audio:上层调用此函数包名称 
  * Opensl:上层调用此函数的类名
  * stopPlay:上层调用的函数名
   * 这几个命名一定要对应，否则上层调用会出现错误:"java.lang.UnsatisfieldLinkError:Native method not found" 
   */
JNIEXPORT jint JNICALL Java_com_potevio_opensl_Opensl_release(JNIEnv * env, jclass obj)
{
	LOGI("Opensl_release %d, %d", (env == NULL), (obj == NULL));
	opensl_destroy(&oa_factory);
    
    return 0;
}